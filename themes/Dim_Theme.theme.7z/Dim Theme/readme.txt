Based on ten-embedded basic theme
Created in purpose of having something close to a dark mode
enjoy ^^

Created by EDM115
Find me on https://github.com/EDM115/ and https://linktr.ee/404__DJ